<?php

interface Github_ApiInterface
{
}
